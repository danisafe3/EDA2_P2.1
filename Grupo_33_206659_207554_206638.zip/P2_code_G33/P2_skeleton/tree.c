/* 
 * tree.c
 *
 * EDA II - Practice 2
 * Practice Group : P302
 *    - Daniel Sanchez (207554)
 *    - Joan Moya (206659)
 *    - Iván Martínez (206638)
 * Group ID : 33
 * 
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "commons.h"
#include "tree.h"


/*
 * Esta función es la encargada de eleminiar y liberar memoria de
 * todos los nodos hijos de un nodo dado, siguiendo un postorden.
 * Para ello utilizamos llamadas recursivas hasta llegar al último nodo hijo.
 */
void clearPostOrder(Node* node) {

    if (node->left_tree != NULL) {
        clearPostOrder(node->left_tree);
        node->left_tree = NULL;
    }
    if (node->right_tree != NULL) {
        clearPostOrder(node->right_tree);
        node->right_tree = NULL;
    }

    if ((node->left_tree == NULL) && (node->right_tree == NULL)) {
        strncpy(node->wi.definition, "\0", MAX_DEFINITION_LENGTH);
        strncpy(node->wi.word, "\0",  MAX_WORD_LENGTH);
        node->wi.pos = '\0';
        free(node);

    } 
}

/*
 * Dado un wordinfo, creamos un nodo usando memoria dinamica y le
 * añadimos el wi que pasamos como argumento. Los hijos de este nuevo
 * nodo son NULL. 
 * Devolvemos la dirección de memoria del nuevo nodo. 
 * 
 */
Node *createNode(WordInfo wi) {

    Node * node = (Node*) malloc(sizeof (Node));

    strncpy(node->wi.word, wi.word, MAX_WORD_LENGTH);
    strncpy(node->wi.definition, wi.definition, MAX_DEFINITION_LENGTH);
    node->wi.pos = wi.pos;

    node->left_tree = NULL;
    node->right_tree = NULL;

    return node;
}

/*
 * Dado un word info y un nodo, crearemos un nuevo nodo
 * en uno de los nodos hijos, dependiendo de si el wi es mayor o menor
 * que el nodo. 
 */

void insertNode(Node* node, WordInfo wi) {

    if (strcmp(node->wi.word, wi.word) > 0) {
        node->left_tree = createNode(wi);
    } else if (strcmp(node->wi.word, wi.word) < 0) {
        node->right_tree = createNode(wi);
    }
}

/*
 * Buscamos a partir de un nodo inicial el nodo que contiene una cierta palabara. 
 * Devolvemos la dirección del nodo que buscamos. 
 */

Node* findNode(Node* node, char* word) {

    if (strcmp(node->wi.word, word) == 0)
        return (node);

    else if (strcmp(node->wi.word, word) > 0) {
        if (node->left_tree == NULL)
            return (node);
        else
            findNode(node->left_tree, word);
    } else if (strcmp(node->wi.word, word) < 0) {
        if (node->right_tree == NULL)
            return (node);
        else
            findNode(node->right_tree, word);
    }
}

/*
 * Función recursiva, que imprime el inorden del arbol
 * con raíz en un nodo dado. 
 * primero visita los nodos más a la izquierda, despues
 * al padre y despues los que se encuentran a la derecha. 
 */

void printInOrder(Node* node) {

    if (node->left_tree != NULL)
        printInOrder(node->left_tree);
    
    print_word_info(node->wi);
    
    if (node->right_tree != NULL)
        printInOrder(node->right_tree);
}

// TREE

/*
 * Dada la dirección de memoria de un arbol, nos encargamos
 * de crear de manera dinamica el primer nodo de manera que no contiene
 * ninguna información y sus hijo son iguales a NULL.
 * El tamaño del arbol es 0, dado que aunque tengamos el primer nodo, este 
 * no contiene ninguna información. 
 */

void init_tree(Tree* t) {

    Node *first;

    first = (Node*) malloc(sizeof (Node));

    first->left_tree = NULL;
    first->right_tree = NULL;

    t->root = first;
    t->size = 0;

} //OK

/*
 * Dado un arbol, vaciamos todos sus nodos y los liberamos.
 * Lo hacemos llamando a la función clearPostOrder que se 
 * inicia desde la raíz de nuestro arbol. 
 */

void clear_tree(Tree* t) {

    printf("Cleaning tree... \n");
    clearPostOrder(t->root);
    t->size = 0 ; 
    printf("Dictionary cleared ! \n");
    
}

/*
 * Dado un wordinfo, nos encargamos primero de evaluar si
 * en nuestro arbol existe un wi con la misma palabra.
 * Si no hay ningun nodo con este wi, lo creamos y lo agregamos a
 * nuestro tree, aumentando el tamaño del diccionario. 
 */

void insert_into_tree(Tree* t, WordInfo wi) {

    Node *aux;

    if (t->size == 0) {
        t->root = createNode(wi);
        print_word_info(wi); 
        t->size++;

    } else if (find_in_tree(t, wi.word) != NULL)
        printf("XX This word (\"%s\")already exists! \n", wi.word);

    else {
        aux = findNode(t->root, wi.word);
        
        if (strcmp(aux->wi.word, wi.word) != 0) {
            insertNode(aux, wi);
        }
        print_word_info(wi); 
        t->size++;

    }
}

/*
 * Devolvemos el wordinfo del nodo que contiene la palabra dado
 * dentro de un cierto arbol. 
 * Si no tenemos ningun nodo en nuestro arbol con esta palabra 
 * devolvemos NULL.  
 */

WordInfo* find_in_tree(Tree* t, char* word) {

    Node* aux;
    aux = findNode(t->root, word);

    if (strcmp(aux->wi.word, word) == 0)
        return (&aux->wi);

    else
        return NULL;

}

/*
 * Devolvemos el tamaño de nuestro tree (la cantidad de palabras que contiene)
 */

int size_tree(Tree* t) {
    return (t->size);
}

/*
 * Teniendo un arbol, llamamos a la función printInOrder que imprime el inorden
 * a partir de nuestro nodo raíz, es decir imprime el inorden de todo el tree.
 * Esta función imprime de manera ordenada nuestro diccionario. 
 */

void print_tree(Tree* t) {
    printf("\n");
    printInOrder(t->root);
}
