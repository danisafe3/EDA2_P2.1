/* 
 * tree.h
 *
 * EDA II - Practice 2
 * Practice Group : P302
 *    - Daniel Sanchez (207554)
 *    - Joan Moya (206659)
 *    - Iván Martínez (206638)
 * Group ID : 33
 * 
 */


#ifndef TREE_H
#define TREE_H

#include "word_info.h"


typedef struct {
    
    Node *root; //puntero al nodo raíz, desde el que nos moveremos y modificaremos el tree
    int size; //numero total de nodos (palabras) que tiene nuestro diccionario (tree)
    
} Tree;

void init_tree(Tree* t);
void clear_tree(Tree* t);
int size_tree(Tree* t);
void insert_into_tree(Tree* t, WordInfo wi);
WordInfo* find_in_tree(Tree* t, char* word);
void print_tree(Tree* t);

#endif /* TREE_H */

