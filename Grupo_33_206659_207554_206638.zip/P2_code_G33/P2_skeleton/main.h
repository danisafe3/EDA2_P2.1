/* 
 * main.h
 *
 * EDA II - Practice 2
 * Practice Group : P302
 *    - Daniel Sanchez (207554)
 *    - Joan Moya (206659)
 *    - Iván Martínez (206638)
 * Group ID : 33
 * 
 */


#ifndef MAIN_H
#define MAIN_H

#define INFO_FILE_PATH "data_dict.tsv"
#define QUERY_FILE_PATH "data_list.tsv"

#endif /* MAIN_H */

