/* 
 * commons.h
 *
 * EDA II - Practice 2
 * Practice Group : P302
 *    - Daniel Sanchez (207554)
 *    - Joan Moya (206659)
 *    - Iván Martínez (206638)
 * Group ID : 33
 * 
 */

#ifndef COMMONS_H
#define COMMONS_H

#define TRUE 1
#define FALSE 0
#define bool int

#define SUCCESS 1
#define ERROR -1

#endif /* COMMONS_H */

