/* 
 * word_info.h
 *
 * EDA II - Practice 2
 * Practice Group : P302
 *    - Daniel Sanchez (207554)
 *    - Joan Moya (206659)
 *    - Iván Martínez (206638)
 * Group ID : 33
 * 
 */

#ifndef WORDINFO_H
#define WORDINFO_H

#define MAX_WORD_LENGTH 30
#define MAX_DEFINITION_LENGTH 100

typedef struct {
    
    char word[MAX_WORD_LENGTH]; //palabra que contiene este nodo
    char definition[MAX_DEFINITION_LENGTH]; //descripcion de la palabra
    char pos; //tipo de palabra
    
} WordInfo;

struct nodes{
    
    WordInfo wi; //cada nodo tiene informacion de una sola palabra
    
    struct nodes *left_tree; // puntero a nodo hijo menor que él
    struct nodes *right_tree; // puntero a nodo hijo mayor que él 
    
};
typedef struct nodes Node;

void create_word_info(WordInfo* wi, char* word, char* definition, char pos);
char* get_word(WordInfo* wi);
void print_word_info(WordInfo wi);

#endif
