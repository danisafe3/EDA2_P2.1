#include <stdlib.h>
#include <string.h>

#include "commons.h"
#include "tree.h"


#include <stdio.h>
// NODE

void clearPostOrder(Node* node) {

    if (node->right_tree != NULL) {
        clearPostOrder(node->right_tree);
        node->right_tree = NULL;
    }
    if (node->left_tree != NULL) {
        clearPostOrder(node->left_tree);
        node->left_tree = NULL;
    }
    if ((node->left_tree == NULL) && (node->right_tree == NULL)) {
        strcpy(node->wi.definition, "\0");
        strcpy(node->wi.word, "\0");
        node->wi.pos = '\0';
        free(node);

    } 


}

Node *createNode(WordInfo wi) {

    Node * node = (Node*) malloc(sizeof (Node));

    strncpy(node->wi.word, wi.word, MAX_WORD_LENGTH);
    strncpy(node->wi.definition, wi.definition, MAX_DEFINITION_LENGTH);
    node->wi.pos = wi.pos;

    node->left_tree = NULL;
    node->right_tree = NULL;

    return node;
}

void insertNode(Node* node, WordInfo wi) {



    if (strcmp(node->wi.word, wi.word) > 0) {
        node->left_tree = createNode(wi);
    } else if (strcmp(node->wi.word, wi.word) < 0) {
        node->right_tree = createNode(wi);
    }

}

Node* findNode(Node* node, char* word) {

    if (strcmp(node->wi.word, word) == 0)
        return (node);

    else if (strcmp(node->wi.word, word) > 0) {
        if (node->left_tree == NULL)
            return (node);
        else
            findNode(node->left_tree, word);
    } else if (strcmp(node->wi.word, word) < 0) {
        if (node->right_tree == NULL)
            return (node);
        else
            findNode(node->right_tree, word);
    }

}

void printInOrder(Node* node) {

    if (node->left_tree != NULL)
        printInOrder(node->left_tree);
    print_word_info(node->wi);
    if (node->right_tree != NULL)
        printInOrder(node->right_tree);
}

// TREE

void init_tree(Tree* t) {

    Node *first;

    first = (Node*) malloc(sizeof (Node));

    first->left_tree = NULL;
    first->right_tree = NULL;


    t->root = first;
    t->size = 0;

} //OK

void clear_tree(Tree* t) {

    printf("Cleaning tree... \n");
    clearPostOrder(t->root);
    t->size = 0 ; 
    printf("Dictionary cleared ! \n");



}

void insert_into_tree(Tree* t, WordInfo wi) {

    Node *aux;

    if (t->size == 0) {
        t->root = createNode(wi);
        printf("-> %s (%c) :%s \n", wi.word, wi.pos, wi.definition);
        t->size++;

    } else if (find_in_tree(t, wi.word) != NULL)
        printf("XX This word (\"%s\")already exists! \n", wi.word);

    else if (find_in_tree(t, wi.word) == NULL) {

        aux = findNode(t->root, wi.word);



        if (strcmp(aux->wi.word, wi.word) != 0) {
            insertNode(aux, wi);
        }
        printf("-> %s (%c) :%s \n", wi.word, wi.pos, wi.definition);
        t->size++;

    }



}

WordInfo* find_in_tree(Tree* t, char* word) {

    Node* aux;
    aux = findNode(t->root, word);


    if (strcmp(aux->wi.word, word) == 0)
        return (&aux->wi);

    else
        return NULL;

}

int size_tree(Tree* t) {
    return (t->size);
}

void print_tree(Tree* t) {
    printf("\n");
    printInOrder(t->root);
}
