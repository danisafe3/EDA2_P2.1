/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   commons.h
 * Author: francesco
 *
 * Created on May 4, 2018, 6:37 PM
 */

#ifndef COMMONS_H
#define COMMONS_H

#define TRUE 1
#define FALSE 0
#define bool int

#define SUCCESS 1
#define ERROR -1

#endif /* COMMONS_H */

